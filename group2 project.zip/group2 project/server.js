const express = require("express");
const mongoose = require("mongoose");
const path = require("path");
const session = require("express-session");
//const mongoStore = require("mongo-store")
const cookieParser = require("cookie-parser");
const passport = require("passport");
const { check, validationResult } = require('express-validator');
const logger = require("morgan");
const ejs = require("ejs");
const bodyParser = require("body-parser");
const ejsLint = require("ejs-lint");
const flash = require("connect-flash");
const methodOverride = require("method-override");
require('dotenv').config("./.env");

const app = express();

const {PORT, mongoDB, globalVariables} = require("./config/configuration");


//assign mongoose promise library and connect to database
mongoose.Promise = global.Promise;

//configure mongoose to connect to mongodb
mongoose.connect( mongoDB, {
    useNewUrlParser: true,
    useUnifiedTopology: true,
    useCreateIndex: true 
})
.then(response => console.log(`Database connected successfully on: ${mongoDB}`))
.catch(err => console.log(`connection db error: ${err}`))


//configure express

app.use(express.json());
app.use(express.urlencoded({ extended: true}));
app.use(express.static(path.join(__dirname, "public")));



//configure other middlewares
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: false }));
app.use(cookieParser());

//app.set('trust proxy', 1) //trust first proxy

//setup flash and sessions
app.use(session({
    secret: "emmy one ",
    saveUninitialized: true,
    resave: true,
    cookie: { maxAge: 56000000 } // 1 hour expiration
}));

//passport
app.use(passport.initialize());
//attach passport to session
app.use(passport.session());


//setting view engine
app.set('views', path.join(__dirname, 'views'))
app.set('view engine', ejs);

//method override middleware
app.use(methodOverride("newMethod"));



//morgan init
app.use(logger('dev'));

//connect flash init
app.use(flash());

// make use of global variables
app.use(globalVariables);



//importing routes
const defaultRoutes = require("./routes/defaultRoutes");
const adminRoutes = require("./routes/adminRoutes");

app.use("/", defaultRoutes);
app.use('/', adminRoutes)

//catching error 404

app.use((req, res, next) => {
    res.render("error404.ejs");
    next();});




app.listen(PORT, () => { console.log(`app running on port ${PORT}`);
});

